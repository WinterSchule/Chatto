const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Serve the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Handle connection event
io.on('connection', (socket) => {
  console.log('A user connected');

  // Listen for 'joinRoom' event to join a specific chatroom
  socket.on('joinRoom', (room) => {
    socket.join(room);
    console.log(`User joined room: ${room}`);

    // Broadcast when a user connects to that specific room
    socket.broadcast.to(room).emit('message', `A user has joined the ${room} chat`);

    // Listen for chatMessage and broadcast it to the specific room
    socket.on('chatMessage', (msg) => {
      io.to(room).emit('message', msg); // Broadcast message only to that room
    });

    // Handle disconnecting from a room
    socket.on('disconnect', () => {
      io.to(room).emit('message', `A user has left the ${room} chat`);
    });
  });
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
